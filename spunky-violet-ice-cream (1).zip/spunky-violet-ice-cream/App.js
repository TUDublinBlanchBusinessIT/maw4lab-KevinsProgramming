import { SafeAreaView, Text, View, TextInput, Button, Alert, StyleSheet } from 'react-native';
import {useState} from 'react';

export default function App() {
  const gradePoints = {'F': 0,'D': 1.5,'C': 2,'C+': 2.75, 'B': 3, 'B+': 3.5,  'A': 4 };
  
  const [sswd, setSswd] = useState('D');
  const [ob, setOb] = useState('D');
  const [mobapps, setmobapps] = useState("D")
  const [digmarket, setdigmarket] = useState("D")
  const [ooad, setooad] = useState("D")
  const [finmage, setfinmanage] = useState("D")

  var gpa=0;
  var credits=5;
  var totalPossibleCredits = 10;
  var totalGradeScores = 0;
  var x=0
  var x1=0

  function clickMe(){
    alert("this is the click me button"); //alert for web
    Alert.alert("this is the click me button"); //alert for phone
    //get the studnet's gradePointsfor SSWD, multiply it by the credits 
    //add the result to totalGradeScores as an accumulator variable (e.g. tgs=tgs+sswd)

    x = gradePoints[sswd] * credits ;
    totalGradeScores = totalGradeScore + x 
    
    //get the student's gradePointsfor Ob, multiply it by the credits
    //add the result to totalGradeScores as an accumulator variable (e.g. tgs=tgs+ob)
   
    x1 = gradePoints[ob] * credits ;
    totalGradeScores = totalGradeScore + x1 

    gpa = totalGradeScores / totalPossibleCredits

    alert(gpa)

    //calculate the gpa as the totalsGradeScores divided by the totalPossibleCredits
    //Output the calculated GPA result to the user using an alert (you must concatenate the gpa)

    gpa = totalGradeScores / totalPossibleCredits
    alert(gpa)
  }

  const styles = StyleSheet.create({
  container: {
    justifyContent: "row",
    flex: 1,

  },
  row: {
    flexdirection: "row",
    marginBottom: "0%",
    marginTop: "2%",
    padding: "5px",

  },
  label: {
    flex: 1,
    textAlign: "right",
    marginRight: "15px",

  },
  textInput: {
    minwidth: "25%",
    borderRadius: "5px",
    border: "1px solid black",
    backgroundColor: "aliceblue"

  }
});

return (

    <SafeAreaView style={styles.container}>
       <View><Text style={{flexDirection: "row", fontWeight: "bold", fontSize: 24, textAlign: "center", marginTop: "%10"}}>GPA Calculator</Text></View>
  <View style={styles.row}>
<Text style = {styles. label}>Maths</Text>
<TextInput style = {styles.textInput} placeholder="Grade" onChangeText={(val)
=> setSswd (val)}/>
</View>
<View style = (styles.row} >
<Text style = (styles.label}>Organisational Behaviour</Text>
<TextInput style = {styles.textInput} placeholder="Grade" onChangeText={(val) =>
setOb (val)}/>
</}>

<Text style = {styles. label)>Financial Management</Text>
<TextInput style = (styles.textInput} placeholden="Grade" onChangeText={(val)
=> setoodp (val))>
</View>
<View style={styles.row}>
<Text style = {styles.textInput} placeholder="Grade" onChangeText={(val)}
=> setdigmarket(val)}/>
</View>
<View>
<Button title="submit" onPress={clickMe}/>
</View>
</SafeAreaView> 
  );
}

